const payment_model = require("../../Models/User Models/payment_model");

exports.add_payment = async (req, res, next) => {
  try {
    let userId = req.query.user_id;
    let transactionId = req.body.transaction_id;
    let mobileNumber = req.body.mobile_number;
    let amount = req.body.amount;
    let operator = req.body.operator;
    let package_id = req.body.package_id;

    payment_model
      .addPayment(
        mobileNumber,
        transactionId,
        operator,
        amount,
        userId,
        package_id
      )
      .then((result) => {
        let data = {
          status: "Success",
          messege: "Payment added successfully",
        };
        res.status(200).json(data);
      });
  } catch (e) {
    console.log(e);
    return res.status(503).json({ msg: "Internal Server Error" });
  }
};
